package com.example.ui.screens.student

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionItem
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraOutlinedButton
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraOrangeLight
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestResultScreen(
    testId: Long,
    testName: String,
    totalQuestions: Int,
    correctCount: Int,
    score: Double,
    answersMapJson: String,
    repository: TestMitraRepository,
    onBackToHome: () -> Unit,
    onRetakeTest: () -> Unit
) {
    var questions by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var isLoadingQuestions by remember { mutableStateOf(true) }

    // Parse answers map
    val answersMap = remember(answersMapJson) {
        try {
            val moshi = Moshi.Builder().build()
            val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
            val adapter = moshi.adapter<Map<String, String>>(type)
            adapter.fromJson(answersMapJson) ?: emptyMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    LaunchedEffect(testId) {
        isLoadingQuestions = true
        when (val res = repository.getQuestionsForTest(testId)) {
            is Resource.Success -> {
                questions = res.data
                isLoadingQuestions = false
            }
            else -> {
                isLoadingQuestions = false
            }
        }
    }

    val wrongCount = totalQuestions - correctCount
    val percentage = if (totalQuestions > 0) (correctCount.toDouble() / totalQuestions.toDouble()) * 100.0 else 0.0

    val grade = when {
        percentage >= 80.0 -> "Outstanding! / શ્રેષ્ઠ!"
        percentage >= 60.0 -> "Good Job! / સરસ પ્રયાસ!"
        percentage >= 40.0 -> "Keep Practicing! / વધુ પ્રેક્ટિસ કરો"
        else -> "Needs Improvement / સુધારાની જરૂર છે"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Test Result / પરિણામ",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MitraNavyPrimary,
                    titleContentColor = Color.White
                )
            )
        },
        modifier = Modifier
            .fillMaxSize()
            .testTag("test_result_screen")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Result Score Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("score_summary_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            modifier = Modifier.size(72.dp),
                            shape = CircleShape,
                            color = if (percentage >= 50) MitraGreenLight else MitraOrangeLight
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (percentage >= 50) Icons.Default.EmojiEvents else Icons.Default.Star,
                                    contentDescription = null,
                                    tint = if (percentage >= 50) MitraGreen else MitraOrange,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = testName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = grade,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (percentage >= 50) MitraGreen else MitraOrange,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Percentage & Score Circle Banner
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MitraBgLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "${score.toInt()} / $totalQuestions",
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MitraNavyPrimary
                                    )
                                    Text(
                                        text = "Final Score\nકુલ ગુણ",
                                        fontSize = 11.sp,
                                        color = MitraTextMuted,
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Surface(
                                    modifier = Modifier
                                        .width(1.dp)
                                        .height(40.dp),
                                    color = MitraBorder
                                ) {}

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = String.format("%.1f%%", percentage),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (percentage >= 50) MitraGreen else MitraError
                                    )
                                    Text(
                                        text = "Percentage\nટકાવારી",
                                        fontSize = 11.sp,
                                        color = MitraTextMuted,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Detailed Metrics: Total, Correct, Wrong
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricChip(
                                label = "Total / કુલ",
                                value = "$totalQuestions",
                                color = MitraNavyPrimary,
                                containerColor = Color(0xFFF1F5F9),
                                modifier = Modifier.weight(1f)
                            )
                            MetricChip(
                                label = "Correct / સાચા",
                                value = "$correctCount",
                                color = MitraGreen,
                                containerColor = MitraGreenLight,
                                modifier = Modifier.weight(1f)
                            )
                            MetricChip(
                                label = "Wrong / ખોટા",
                                value = "$wrongCount",
                                color = MitraError,
                                containerColor = MitraErrorLight,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Action Button: Back to Home
            item {
                MitraPrimaryButton(
                    text = "Back to Home / હોમ પર જાઓ",
                    onClick = onBackToHome,
                    icon = Icons.Default.Home,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "back_home_button"
                )
            }

            // Section Header: Detailed Question-by-Question Review
            item {
                Text(
                    text = "Question Review / પ્રશ્ન સમીક્ષા",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MitraNavyPrimary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (isLoadingQuestions) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = MitraNavyPrimary)
                    }
                }
            } else {
                itemsIndexed(questions) { index, q ->
                    val qId = q.id ?: 0L
                    val studentAnswer = answersMap[qId.toString()] ?: ""
                    val correctOpt = q.normalizedCorrectOption()
                    val isCorrect = studentAnswer.isNotBlank() && studentAnswer.equals(correctOpt, ignoreCase = true)

                    QuestionReviewCard(
                        index = index + 1,
                        question = q,
                        studentAnswer = studentAnswer,
                        correctOption = correctOpt,
                        isCorrect = isCorrect
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricChip(
    label: String,
    value: String,
    color: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = containerColor,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                color = color,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun QuestionReviewCard(
    index: Int,
    question: QuestionItem,
    studentAnswer: String,
    correctOption: String,
    isCorrect: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("review_card_$index"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(
            1.dp,
            if (isCorrect) MitraGreen.copy(alpha = 0.5f) else MitraError.copy(alpha = 0.4f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Q Number + Correct/Wrong status badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MitraNavyPrimary
                ) {
                    Text(
                        text = "Q $index",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isCorrect) MitraGreenLight else MitraErrorLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = null,
                            tint = if (isCorrect) MitraGreen else MitraError,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isCorrect) "Correct / સાચું" else if (studentAnswer.isBlank()) "Unanswered / બાકી" else "Wrong / ખોટું",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCorrect) MitraGreen else MitraError
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Question Text
            Text(
                text = question.questionText,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MitraTextPrimary,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Options List with highlights
            ReviewOptionRow("A", question.optionA, studentAnswer == "A", correctOption == "A")
            Spacer(modifier = Modifier.height(6.dp))
            ReviewOptionRow("B", question.optionB, studentAnswer == "B", correctOption == "B")
            Spacer(modifier = Modifier.height(6.dp))
            ReviewOptionRow("C", question.optionC, studentAnswer == "C", correctOption == "C")
            Spacer(modifier = Modifier.height(6.dp))
            ReviewOptionRow("D", question.optionD, studentAnswer == "D", correctOption == "D")

            Spacer(modifier = Modifier.height(10.dp))

            // Result Answer Summary Banner
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, MitraBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Your Choice: ${if (studentAnswer.isNotBlank()) "Option $studentAnswer" else "None"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isCorrect) MitraGreen else MitraError
                    )
                    Text(
                        text = "Correct: Option $correctOption",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun ReviewOptionRow(
    letter: String,
    text: String,
    isStudentChoice: Boolean,
    isCorrectOption: Boolean
) {
    val bgColor = when {
        isCorrectOption -> MitraGreenLight
        isStudentChoice -> MitraErrorLight
        else -> Color(0xFFF8FAFC)
    }

    val borderColor = when {
        isCorrectOption -> MitraGreen
        isStudentChoice -> MitraError
        else -> MitraBorder
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(24.dp),
                shape = CircleShape,
                color = when {
                    isCorrectOption -> MitraGreen
                    isStudentChoice -> MitraError
                    else -> Color(0xFFE2E8F0)
                }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = letter,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCorrectOption || isStudentChoice) Color.White else MitraTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
                text = text,
                fontSize = 13.sp,
                color = MitraTextPrimary,
                modifier = Modifier.weight(1f)
            )

            if (isCorrectOption) {
                Text(
                    text = "✓ Correct",
                    fontSize = 11.sp,
                    color = MitraGreen,
                    fontWeight = FontWeight.Bold
                )
            } else if (isStudentChoice) {
                Text(
                    text = "✗ Your Answer",
                    fontSize = 11.sp,
                    color = MitraError,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
